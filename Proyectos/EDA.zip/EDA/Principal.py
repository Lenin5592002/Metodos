# Principal.py

from Interfaz import Interfaz

# Principal.py

import tkinter as tk


def main():
    root = tk.Tk()
    root.geometry("1000x700")  # tamaño de la ventana
    app = InterfazGraficaGrafo(root)
    root.mainloop()


if __name__ == "__main__":
    main()
