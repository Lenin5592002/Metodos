# Interfaz.py

import os
from Grafo import Grafo


class InterfazGrafo:
    def __init__(self):
        # Grafo NO dirigido (puedes cambiar a True si quieres dirigido)
        self.grafo = Grafo(dirigido=False)

    def mostrar_menu(self):
        print("\n===== MENÚ GRAFO (BFS / DFS) =====")
        print("1. Agregar nodo")
        print("2. Agregar arista")
        print("3. Mostrar grafo (nodos y aristas)")
        print("4. Ejecutar BFS (ruta más corta)")
        print("5. Ejecutar DFS (exploración en profundidad)")
        print("6. Leer grafo desde archivo .txt")
        print("7. Salir")

    def pedir_opcion(self):
        opcion = input("Elige una opción: ")
        return opcion.strip()

    # ------------ Opciones del menú ------------ #

    def opcion_agregar_nodo(self):
        id_nodo = input("ID del nodo: ").strip()
        if not id_nodo:
            print("ID vacío. No se agregó el nodo.")
            return
        self.grafo.agregar_nodo(id_nodo)
        print(f"Nodo '{id_nodo}' agregado.")

    def opcion_agregar_arista(self):
        origen = input("Nodo origen: ").strip()
        destino = input("Nodo destino: ").strip()
        if not origen or not destino:
            print("Origen o destino vacío. No se agregó la arista.")
            return
        self.grafo.agregar_arista(origen, destino)
        print(f"Arista agregada entre '{origen}' y '{destino}'.")

    def opcion_mostrar_grafo(self):
        if not self.grafo.nodos:
            print("El grafo está vacío.")
            return

        print("\n--- Nodos ---")
        for nid in self.grafo.nodos:
            print(f"- {nid}")

        print("\n--- Aristas (lista de adyacencia) ---")
        for origen_id, aristas in self.grafo.adyacencia.items():
            destinos = [a.destino.id for a in aristas]
            print(f"{origen_id} -> {destinos}")
        print()

    def opcion_bfs(self):
        if not self.grafo.nodos:
            print("El grafo está vacío. Agrega nodos/aristas primero.")
            return

        start = input("Nodo inicio (start): ").strip()
        goal = input("Nodo objetivo (goal): ").strip()

        try:
            resultado = self.grafo.bfs(start, goal)
        except ValueError as e:
            print(f"Error: {e}")
            return

        print("\n=== Resultado BFS ===")
        print("Distancias:", resultado["distancias"])
        print("Padres:", resultado["padres"])
        print("Ruta más corta:", resultado["ruta_mas_corta"])
        print("Árbol BFS (padre -> hijo):", resultado["arbol_bfs"])
        print(f"Tiempo de ejecución: {resultado['tiempo']:.8f} segundos")

    def opcion_dfs(self):
        if not self.grafo.nodos:
            print("El grafo está vacío. Agrega nodos/aristas primero.")
            return

        start = input("Nodo inicio (start): ").strip()
        goal = input("Nodo objetivo (goal): ").strip()

        try:
            resultado = self.grafo.dfs(start, goal)
        except ValueError as e:
            print(f"Error: {e}")
            return

        print("\n=== Resultado DFS ===")
        print("Padres:", resultado["padres"])
        print("Ruta encontrada por DFS:", resultado["ruta_dfs"])
        print("Árbol DFS (padre -> hijo):", resultado["arbol_dfs"])
        print("Camino de mayor profundidad desde start:",
              resultado["camino_mayor_profundidad"])
        print(f"Tiempo de ejecución: {resultado['tiempo']:.8f} segundos")

    # ------------ Cargar grafo desde archivo (AUTOMÁTICO) ------------ #

    def opcion_cargar_desde_archivo(self):
        # Ruta automática: mismo folder que este archivo + Campus.txt
        ruta = os.path.join(os.path.dirname(__file__), "Campus.txt")

        print(f"\nCargando grafo desde: {ruta}\n")

        try:
            # Reiniciar grafo
            self.grafo = Grafo(dirigido=False)

            with open(ruta, "r", encoding="utf-8") as f:
                for linea in f:
                    linea = linea.strip()
                    # Ignorar líneas vacías y comentarios
                    if not linea or linea.startswith("#"):
                        continue

                    partes = [p.strip() for p in linea.split(",")]
                    if len(partes) != 2:
                        print(f"Línea inválida, se ignora: {linea}")
                        continue

                    origen, destino = partes
                    self.grafo.agregar_arista(origen, destino)

            print("Grafo cargado correctamente.\n")
            self.opcion_mostrar_grafo()

        except FileNotFoundError:
            print(f"ERROR: No se encontró el archivo: {ruta}")
        except Exception as e:
            print(f"Ocurrió un error al leer el archivo: {e}")

    # ------------ Bucle principal ------------ #

    def ejecutar(self):
        while True:
            self.mostrar_menu()
            opcion = self.pedir_opcion()

            if opcion == "1":
                self.opcion_agregar_nodo()
            elif opcion == "2":
                self.opcion_agregar_arista()
            elif opcion == "3":
                self.opcion_mostrar_grafo()
            elif opcion == "4":
                self.opcion_bfs()
            elif opcion == "5":
                self.opcion_dfs()
            elif opcion == "6":
                self.opcion_cargar_desde_archivo()
            elif opcion == "7":
                print("Saliendo...")
                break
            else:
                print("Opción no válida. Intenta de nuevo.")
